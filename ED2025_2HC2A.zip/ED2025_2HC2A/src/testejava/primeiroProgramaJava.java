package testejava;

import java.util.Scanner;

public class primeiroProgramaJava {

	public static void main(String[]args) {
		Scanner scan = new Scanner(System.in);
		int num1;
		int num2;
		System.out.print("Digite o valor do num1:");
		num1 = scan.nextInt();
		System.out.print("Digite o valor do num2:");
		num2 = scan.nextInt();
		System.out.println("a soma é "+(num1+num2));

		if (num1 > 10) {

			System.out.println("o valor de num1 é maior que 10");

		}else {

			if (num1 ==10) {
				System.out.println("o valor de num1 é igual a 10");

			}else {

				System.out.println("o valor num1 é menor que 10");

			}
		}	

		//comandos de repetição

		int i = 0;

		System.out.println("while");
		while (i < 5) {
			System.out.println("i = " + i);
			i++;
		}

		System.out.println("for");
		for (i = 0; i < 5; i++) {
			System.out.println("i = " + i);

		}

		System.out.println("do while");
		i = 0;
		do {
			System.out.println("i = " + i);
			i++;
		} while (i < 5);


	}
	
}



